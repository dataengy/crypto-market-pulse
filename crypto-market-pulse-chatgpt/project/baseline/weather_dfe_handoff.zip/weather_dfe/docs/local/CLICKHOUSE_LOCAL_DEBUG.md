# Draft: ClickHouse + Redpanda local debugging profile

**Status:** proposed local design and unintegrated SQL example, NOT a deployed pipeline. Start with [`LOCAL_RUNTIME_REUSE_POLICY.md`](LOCAL_RUNTIME_REUSE_POLICY.md), then run `python3 scripts/discover_local_runtime.py --markdown` in the repository root.

## Runtime decision tree

1. Find a compatible host ClickHouse server (`clickhouse server`, `clickhouse-client`, HTTP endpoint). Prefer **existing host installation** if it can run an isolated `weather_dfe` database; do not start a second server if the current one works.
2. Find host Redpanda (`redpanda`, `rpk`) or a reachable host Kafka broker (`kcat`); validate API and advertised listeners.
3. If an OS service for either is absent, inspect **existing Docker/Colima** Redpanda/Kafka and ClickHouse containers and their exposed ports; reuse only if compatible and permitted.
4. If the combination is incomplete, create **only missing** components, using a project-owned Compose service and reusing existing container images when possible. Do not create a second Redpanda/ClickHouse merely because a template includes both.
5. PostgreSQL, Airbyte, Spark, and MiniLake are optional adjacent tooling. Inventory them, but **do not launch them for this profile** unless a test explicitly requires them.

## Pipeline

```text
Open-Meteo fixture/synthetic source
  └─ shared Python publisher (`confluent-kafka`, key=city)
     └─ Kafka topic weather.observations.v1 (Redpanda local)
        └─ Python sink adapter (development only; consumer group weather-dfe-local-v1)
           └─ ClickHouse OSS weather_dfe.weather_raw (append-only MergeTree)
              ├─ `weather_latest` query/view (dedup by observation_key and revision)
              ├─ `weather_1m` query/view (event-time buckets)
              └─ dashboard/SQL query
```

Use host endpoints from the inventory (e.g. `localhost:19092` and `localhost:8123` **only when confirmed**); do not hardcode credentials, infer docker service DNS from host, or assume default ports are free.

## SQL draft — ClickHouse

Versioned reference: `drafts/clickhouse/001_weather_raw.sql` and `drafts/clickhouse/002_weather_latest.sql`. DDL intentionally avoids ingesting through ClickHouse Kafka Engine to keep the first local workflow aligned with a restartable Python debug adapter. An optional **second** experiment may compare Kafka Engine + materialized view to the adapter; the managed cloud path still uses ClickPipes, not this local consumer.

The debug adapter must commit offsets only after successful ClickHouse insert acknowledgement. Deliberately crash after the DB write and before the offset commit to prove duplicate delivery; do not assert exact-once ingestion. Query latest observations deterministically even with repeated and corrected input. If using an MV, document insert-time vs read-time semantics and backfill.

## Local commands (to implement in justfile)

```bash
just local-inventory
just clickhouse-local-preflight    # report discovered host/container providers; no changes
just clickhouse-local-up           # starts ONLY project-owned missing components, opt-in
just clickhouse-produce-demo       # known fixture + duplicate + correction
just clickhouse-local-test         # raw, dedup, 1m and retry checks
just clickhouse-local-down         # leaves reused services untouched
```

Smoke assertions: 3 unique events + 2 repeats yield 5 raw deliveries (depending on producer retries), latest query returns 3 logical latest records; a revision supersedes earlier value at same `(source,city,observed_at)`; hourly delay vs `observed_at` is measured separately; 1m window counts distinct canonical observations (not ingestion attempts). Include out-of-order and invalid events. For manual diagnostic reads use isolated DB and `SELECT count(), min(observed_at), max(observed_at) FROM weather_dfe.weather_raw`.

## Test/CI split

- Unit: schema/normalization, stable event ID, SQL golden fixtures.
- Integration local: real Redpanda + ClickHouse (existing if permitted, otherwise hermetic fresh containers) and restartable consumer.
- CI: **always use fresh temporary test services**; no dependence on developer laptop containers.
- ClickHouse Cloud: separate manually started Confluent Cloud → ClickPipes integration, not considered covered by local passing tests.

## Troubleshooting

- Kafka `Connection refused`: inspect `docker port`, `docker logs`, advertised listeners and `bootstrap.servers`. Host `localhost:19092` is not valid inside another container.
- No ClickHouse rows: inspect consumer group lag, sink insert errors and whether Kafka offsets were committed before insert (must not).
- Duplicate rows: expected under at-least-once; fix query-level dedup semantics instead of assuming physical dedup.
- Port conflict: choose the discovered live service or rebind **new project-owned** container; never kill another process.
- Apple Silicon: prefer arm64 native images; record selected versions and architecture.

References:
- https://docs.redpanda.com/labs/docker-compose/single-broker/
- https://clickhouse.com/docs/integrations/kafka/kafka-table-engine
- https://clickhouse.com/docs/integrations/data-ingestion/clickpipes/kafka/reference
