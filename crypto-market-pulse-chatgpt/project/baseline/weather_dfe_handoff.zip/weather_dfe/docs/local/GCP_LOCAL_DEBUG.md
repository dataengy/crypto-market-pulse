# Draft: native GCP streaming local debug (Beam + Pub/Sub emulator)

**Status:** proposed split-test design and example Beam code, not a Dataflow or BigQuery deployment. Use [`LOCAL_RUNTIME_REUSE_POLICY.md`](LOCAL_RUNTIME_REUSE_POLICY.md) **before** installing the Cloud SDK, Java, Python or starting containers.

## First choose the simplest required test scope

| Question | Local tool | What it proves | What it does NOT prove |
|---|---|---|---|
| Does event-time window logic handle late/out-of-order observations? | **Apache Beam `TestStream` + DirectRunner** (installed Python env first) | watermark/allowed lateness/trigger behavior | Pub/Sub transport, Dataflow worker runtime |
| Can our producer publish and subscriber receive? | **Pub/Sub Emulator** (`gcloud beta emulators pubsub start` if installed; existing container second) | client encoding, retry/ack, topic naming | BigQuery managed subscription delivery |
| Do SQL marts dedup and aggregate correctly? | fixture-driven SQL tests locally; DuckDB as optional approximation | logical semantics on fixtures | full BigQuery dialect, streaming buffer behaviour |
| Does native Pub/Sub → BigQuery actually work? | real GCP opt-in manual smoke | cloud delivery, IAM, schema | free/offline CI |
| Do advanced transformations work on Dataflow? | DataflowRunner **manual opt-in** | GCP streaming runtime | CI without cloud credentials |

## Local discovery

1. Detect installed `python3`, `gcloud`, `java`, `terraform`, `bq`, optional `duckdb`, `docker`, `colima` in `PATH`, `~/.apps/` and `~/.app/` using `scripts/discover_local_runtime.py`.
2. Prefer existing installed Cloud SDK with Pub/Sub emulator component. Inspect `gcloud components list` only read-only (if installed); if managed SDK disables component manager, document local installation instructions as a separate opt-in.
3. If host gcloud emulator is unavailable, inspect compatible **existing** Pub/Sub emulator containers through active Docker/Colima context. Only then propose a **new project-owned** emulator container.
4. Prefer pre-existing Python env containing compatible `apache_beam` for DirectRunner tests; never pollute global Python. Create repo `.venv` only if no compatible isolated env is available; request approval before installing packages.
5. `Minilake` is Databricks SDK/SQL only; `Spark` is for the Databricks profile; neither emulates BigQuery Subscription. Airbyte/Postgres aren't needed for the GCP MVP.

## Test 1: streaming/event-time logic (no GCP)

The draft test lives in `drafts/gcp/test_beam_windows.py`. It uses bounded `TestStream`, independent event timestamps and watermarks, a one-minute fixed window, and verifies canonical count/average. Realistic lateness handling should be added to project Beam transforms and separately asserted across triggers. The DirectRunner is a developer/test runner, not cloud Dataflow; do not run a persistent streaming job for a one-off test.

Run after selecting an existing compatible Python environment:

```bash
python3 -c 'import apache_beam; print(apache_beam.__version__)'
python3 -m pytest drafts/gcp/test_beam_windows.py -q
```

## Test 2: Pub/Sub publisher/subscriber API (no GCP account)

If `gcloud` and the emulator component are already installed:

```bash
# Terminal A: confirm free port first; project ID is local-only
PUBSUB_PROJECT_ID=weather-dfe-local gcloud beta emulators pubsub start \
  --project=weather-dfe-local --host-port=127.0.0.1:8085

# Terminal B (shell environment only; do NOT commit these settings):
export PUBSUB_EMULATOR_HOST=127.0.0.1:8085
export PUBSUB_PROJECT_ID=weather-dfe-local
# Run Python clients using google-cloud-pubsub SDK, NOT `gcloud pubsub topics ...`.
python -m pytest tests/integration/pubsub_emulator -q
```

If port 8085 is occupied, select another port; do not terminate an unrelated service. `PUBSUB_EMULATOR_HOST` must be passed to the process actually running the clients; unset it before real GCP integration to avoid false-positive tests:

```bash
unset PUBSUB_EMULATOR_HOST PUBSUB_PROJECT_ID
```

The official Pub/Sub Emulator **does not forward BigQuery subscriptions into BigQuery**, even if creating a BigQuery subscription succeeds. Therefore only a protected, manual smoke test can verify Pub/Sub → BigQuery. Emulator IAM behavior is also not production-equivalent.

## Test 3: cloud smoke (opt-in only)

Cloud Scheduler → Cloud Run Job → Pub/Sub → BigQuery Subscription → `weather_raw` → SQL views. Use IaC in a disposable GCP project or isolated prefixed resources, least privilege, quotas/budget, short execution, explicit teardown. Distinguish `observed_at` (weather measurement) and `collected_at` (poller). Test at-least-once retries and SQL-level dedup; do not promise exactly once.

## CI design

- Required fast job: parser/contract/SQL fixture tests + Beam DirectRunner/TestStream. No gcloud, Docker, or credentials needed for Beam TestStream if Beam dependency is present.
- Optional Docker job: isolated Pub/Sub emulator with Python SDK producer/subscriber. Never create real cloud resources automatically.
- Manual workflow: real Pub/Sub BigQuery Subscription and (later) DataflowRunner, protected environment and cost limits.

## Key references

- https://beam.apache.org/documentation/programming-guide/
- https://beam.apache.org/get-started/quickstart/python/
- https://docs.cloud.google.com/pubsub/docs/emulator
- https://docs.cloud.google.com/pubsub/docs/bigquery
- https://docs.cloud.google.com/dataflow/docs/guides/develop-and-test-pipelines
