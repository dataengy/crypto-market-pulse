"""No services required; tests ensure scanner is robust and conservative."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'discover_local_runtime.py'
spec = importlib.util.spec_from_file_location('discovery_weather', SCRIPT)
discovery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(discovery)

class DiscoveryTests(unittest.TestCase):
    def test_absent_dirs(self):
        with tempfile.TemporaryDirectory() as t:
            self.assertEqual(discovery.possible_binaries(Path(t), {'nonexistent'}), {})
    def test_finds_executable_in_apps(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t) / '.apps' / 'Redpanda' / 'bin' / 'rpk'
            p.parent.mkdir(parents=True)
            p.write_text('#!/bin/sh\nexit 0\n')
            p.chmod(0o755)
            self.assertEqual(discovery.possible_binaries(Path(t), {'rpk'}), {'rpk': [str(p)]})
    def test_finds_app_bundles(self):
        with tempfile.TemporaryDirectory() as t:
            bundle=Path(t) / 'Applications' / 'Docker.app'
            bundle.mkdir(parents=True)
            self.assertIn(str(bundle), discovery.discover_app_bundles(Path(t)))
    def test_json_lines_skips_invalid(self):
        self.assertEqual(discovery.json_lines('not json\n{"Names":"rp"}'), [{'Names':'rp'}])

if __name__ == '__main__': unittest.main()
