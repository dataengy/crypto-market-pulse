"""Local unit tests; do not require a live Databricks workspace."""
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from weather.settings import load_settings, validate_identifier
from weather.utils import render_sql, statement_sql
from weather.collector import get_current_weather, make_parameters
from build_dashboard import build_dashboard
from build_pipeline_sql import generated_files, model_sql


class ProjectTests(unittest.TestCase):
    def test_config(self):
        config = load_settings(ROOT / "config/settings.yml", environ={})
        self.assertEqual(config.weather.city, "Batumi")
        self.assertEqual(config.databricks.catalog, "workspace")

    def test_environment_override(self):
        config = load_settings(ROOT / "config/settings.yml", environ={
            "DATABRICKS_CATALOG": "test_catalog", "WEATHER_CITY": "Warsaw"})
        self.assertEqual(config.databricks.catalog, "test_catalog")
        self.assertEqual(config.weather.city, "Warsaw")

    def test_sql_identifiers_reject_injection(self):
        for name in ("a-b", "db;DROP TABLE x", "a.b", "", "3cats"):
            with self.assertRaises(ValueError):
                validate_identifier(name)

    def test_sql_is_external(self):
        config = load_settings(ROOT / "config/settings.yml", environ={})
        sql = statement_sql("sql/ingestion/insert_weather.sql", config.databricks, ROOT)
        self.assertIn("`workspace`.`weather_demo`.weather_raw", sql)
        self.assertIn(":temp_c", sql)
        self.assertNotIn("{{", sql)

    def test_render_unknown_placeholder(self):
        config = load_settings(ROOT / "config/settings.yml", environ={})
        with self.assertRaises(ValueError):
            render_sql("{{evil}}", config.databricks)

    def test_collector_payload(self):
        config = load_settings(ROOT / "config/settings.yml", environ={})
        sample = {"current": {"time": "2026-10-25T12:00", "temperature_2m": 22,
                              "relative_humidity_2m": 69, "wind_speed_10m": 11}}
        with patch("weather.collector.fetch_json", return_value=sample):
            observation = get_current_weather(config)
        self.assertEqual(observation["temp_c"], 22)
        self.assertEqual(len(make_parameters(observation)), 7)
        self.assertEqual(observation["source"], "open-meteo")

    def test_sql_generator_matches_committed(self):
        for path, generated in generated_files().items():
            self.assertEqual((ROOT / path).read_text(), generated)

    def test_canonical_models_used_by_both_engines(self):
        for name in ("10_silver", "20_gold"):
            local = model_sql(name, "local_table")
            self.assertIn("FROM local_table", local)
            self.assertNotIn("{{source}}", local)
        self.assertIn("STREAM(${weather.raw_table})", generated_files()["sql/pipelines/10_silver.sql"])

    def test_dashboard_query_generated_from_sql(self):
        expected = build_dashboard()
        committed = json.loads((ROOT / "dashboards/weather.lvdash.json").read_text())
        self.assertEqual(expected, committed)
        self.assertEqual(len(expected["pages"][0]["layout"]), 3)


if __name__ == "__main__":
    unittest.main()
