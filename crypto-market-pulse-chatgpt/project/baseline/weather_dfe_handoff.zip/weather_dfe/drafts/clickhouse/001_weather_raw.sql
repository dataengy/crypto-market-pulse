-- DRAFT ONLY: execute only in a dedicated weather_dfe database, after approval.
CREATE DATABASE IF NOT EXISTS weather_dfe;
CREATE TABLE IF NOT EXISTS weather_dfe.weather_raw
(
    event_id String,
    schema_version UInt8,
    source LowCardinality(String),
    city LowCardinality(String),
    observed_at DateTime64(3, 'UTC'),
    collected_at DateTime64(3, 'UTC'),
    temp_c Nullable(Float64),
    humidity_pct Nullable(UInt8),
    wind_kmh Nullable(Float64),
    mode LowCardinality(String),
    ingested_at DateTime64(3, 'UTC') DEFAULT now64(3)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(observed_at)
ORDER BY (mode, city, source, observed_at, event_id);
