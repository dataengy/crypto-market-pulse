-- DRAFT ONLY: assumes unique event_id per content revision; prefer latest collected_at.
-- ORDER BY event_id provides a stable tie-break for equal collected_at.
-- Full correction semantics must match shared domain contract before production use.
CREATE VIEW IF NOT EXISTS weather_dfe.weather_latest AS
SELECT source, city, mode, observed_at, collected_at, temp_c, humidity_pct, wind_kmh, event_id
FROM (
    SELECT *, row_number() OVER (
        PARTITION BY source, city, mode
        ORDER BY observed_at DESC, collected_at DESC, event_id DESC
    ) AS row_n
    FROM (
        SELECT *, row_number() OVER (
            PARTITION BY source, city, mode, observed_at
            ORDER BY collected_at DESC, event_id DESC
        ) AS revision_n
        FROM weather_dfe.weather_raw
        WHERE temp_c BETWEEN -100 AND 70 AND humidity_pct BETWEEN 0 AND 100
    ) WHERE revision_n = 1
) WHERE row_n = 1;
