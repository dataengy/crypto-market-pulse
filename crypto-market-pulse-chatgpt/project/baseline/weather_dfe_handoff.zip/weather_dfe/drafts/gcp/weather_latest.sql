-- DRAFT BigQuery Standard SQL, not executed locally against BigQuery.
-- Replace `PROJECT.DATASET` through validated IaC/template substitution only.
CREATE OR REPLACE VIEW `PROJECT.DATASET.weather_latest` AS
WITH canonical AS (
  SELECT * EXCEPT(rn) FROM (
    SELECT *, ROW_NUMBER() OVER (
      PARTITION BY source, city, mode, observed_at
      ORDER BY collected_at DESC, event_id DESC
    ) AS rn
    FROM `PROJECT.DATASET.weather_raw`
    WHERE temp_c BETWEEN -100 AND 70 AND humidity_pct BETWEEN 0 AND 100
  ) WHERE rn=1
)
SELECT source, city, mode, observed_at, collected_at, temp_c, humidity_pct, wind_kmh, event_id
FROM canonical
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY source, city, mode
  ORDER BY observed_at DESC, collected_at DESC, event_id DESC
) = 1;
