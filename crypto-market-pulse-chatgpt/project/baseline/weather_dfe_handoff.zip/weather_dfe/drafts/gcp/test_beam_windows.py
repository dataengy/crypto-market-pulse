"""Draft Beam TestStream: deterministic event-time one-minute aggregation.

Run only if apache_beam and pytest already exist in the selected environment.
Not wired to GCP, no external calls.
"""
import apache_beam as beam
from apache_beam.testing.test_pipeline import TestPipeline
from apache_beam.testing.test_stream import TestStream
from apache_beam.testing.util import assert_that, equal_to
from apache_beam.transforms.window import FixedWindows, TimestampedValue


def test_window_counts():
    stream = (TestStream()
              .add_elements([TimestampedValue(('Batumi', 18.0), 1),
                             TimestampedValue(('Batumi', 20.0), 31)])
              .advance_watermark_to(60)
              .advance_watermark_to_infinity())
    with TestPipeline() as p:
        rows = p | stream | beam.WindowInto(FixedWindows(60))
        counts = (rows | beam.Map(lambda x: (x[0], 1)) | beam.CombinePerKey(sum))
        averages = rows | beam.combiners.Mean.PerKey()
        assert_that(counts, equal_to([('Batumi', 2)]), label='AssertCounts')
        assert_that(averages, equal_to([('Batumi', 19.0)]), label='AssertMeans')
