"""Typed configuration for the weather demo.

`config/settings.yml` holds app defaults. Environment overrides are useful in CI.
Bundle variables in `databricks.yml` control the Databricks deployment.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os
import re
from typing import Mapping

import yaml

_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def validate_identifier(value: str) -> str:
    if not isinstance(value, str) or not _IDENT.fullmatch(value):
        raise ValueError(f"Unsafe SQL identifier: {value!r}")
    return value


@dataclass(frozen=True)
class WeatherSettings:
    city: str
    latitude: float
    longitude: float
    api_url: str
    poll_minutes: int
    demo_interval_seconds: float
    demo_events: int


@dataclass(frozen=True)
class DatabricksSettings:
    catalog: str
    schema: str

    @property
    def raw_table(self) -> str:
        return f"`{self.catalog}`.`{self.schema}`.`weather_raw`"


@dataclass(frozen=True)
class Settings:
    weather: WeatherSettings
    databricks: DatabricksSettings


def load_settings(path: str | Path | None = None,
                  environ: Mapping[str, str] | None = None) -> Settings:
    location = Path(path) if path else Path(__file__).resolve().parents[2] / "config/settings.yml"
    with location.open(encoding="utf-8") as stream:
        data = yaml.safe_load(stream)
    if not isinstance(data, dict):
        raise ValueError("settings.yml must contain a YAML mapping")
    weather = data.get("weather") or {}
    db = data.get("databricks") or {}
    env = os.environ if environ is None else environ

    settings = Settings(
        weather=WeatherSettings(
            city=str(env.get("WEATHER_CITY", weather["city"])),
            latitude=float(env.get("WEATHER_LATITUDE", weather["latitude"])),
            longitude=float(env.get("WEATHER_LONGITUDE", weather["longitude"])),
            api_url=str(weather["api_url"]),
            poll_minutes=int(env.get("WEATHER_POLL_MINUTES", weather["poll_minutes"])),
            demo_interval_seconds=float(weather["demo_interval_seconds"]),
            demo_events=int(weather["demo_events"]),
        ),
        databricks=DatabricksSettings(
            catalog=validate_identifier(str(env.get("DATABRICKS_CATALOG", db["catalog"]))),
            schema=validate_identifier(str(env.get("DATABRICKS_SCHEMA", db["schema"]))),
        ),
    )
    w = settings.weather
    if not w.city or not -90 <= w.latitude <= 90 or not -180 <= w.longitude <= 180:
        raise ValueError("Invalid city/latitude/longitude")
    if not w.api_url.startswith("https://"):
        raise ValueError("Weather API must use HTTPS")
    if w.poll_minutes < 1 or w.demo_interval_seconds <= 0 or w.demo_events < 1:
        raise ValueError("Invalid polling/demo intervals")
    return settings
