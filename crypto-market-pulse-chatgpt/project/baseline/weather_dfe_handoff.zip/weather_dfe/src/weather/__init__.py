"""Weather demo: Python for ingestion, SQL for transformations."""
