"""Open-Meteo polling outside DFE -> append-only Delta bronze via SQL API."""
from __future__ import annotations

from datetime import datetime, timezone
import os
from urllib.parse import urlencode
import uuid

from .settings import Settings, load_settings
from .utils import execute_statement, fetch_json, statement_sql


def get_current_weather(config: Settings) -> dict:
    w = config.weather
    query = urlencode({
        "latitude": w.latitude,
        "longitude": w.longitude,
        "current": "temperature_2m,relative_humidity_2m,wind_speed_10m",
        "timezone": "UTC",
    })
    payload = fetch_json(f"{w.api_url}?{query}")
    current = payload["current"]
    # The API uses UTC because timezone=UTC was requested.
    observed = datetime.fromisoformat(current["time"]).replace(tzinfo=timezone.utc)
    return {
        "event_id": str(uuid.uuid4()),
        "city": w.city,
        "observed_at": observed.isoformat(),
        "temp_c": float(current["temperature_2m"]),
        "humidity_pct": float(current["relative_humidity_2m"]),
        "wind_kmh": float(current["wind_speed_10m"]),
        "source": "open-meteo",
    }


def make_parameters(record: dict) -> list[dict]:
    return [
        {"name": field, "value": str(record[field]), "type": data_type}
        for field, data_type in (
            ("event_id", "STRING"), ("city", "STRING"),
            ("observed_at", "STRING"), ("temp_c", "DOUBLE"),
            ("humidity_pct", "DOUBLE"), ("wind_kmh", "DOUBLE"),
            ("source", "STRING"),
        )
    ]


def main() -> None:
    config = load_settings()
    record = get_current_weather(config)
    sql = statement_sql("sql/ingestion/insert_weather.sql", config.databricks)
    execute_statement(
        os.environ["DATABRICKS_HOST"], os.environ["DATABRICKS_TOKEN"],
        os.environ["DATABRICKS_WAREHOUSE_ID"], sql,
        make_parameters(record),
    )
    print(f"Inserted {record['city']} observation at {record['observed_at']}")


if __name__ == "__main__":
    main()
