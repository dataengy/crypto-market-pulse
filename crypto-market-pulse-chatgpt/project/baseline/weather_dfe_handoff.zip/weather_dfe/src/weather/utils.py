"""Small shared utilities; no transformation/business SQL in Python."""
from __future__ import annotations

import json
from pathlib import Path
import re
import time
from urllib.request import Request, urlopen

from .settings import DatabricksSettings

_TEMPLATE = re.compile(r"\{\{(catalog|schema)\}\}")


def project_root() -> Path:
    """Find repo root even when invoked from a Databricks notebook directory."""
    candidates = [Path.cwd(), *Path.cwd().parents, Path(__file__).resolve().parents[2]]
    for root in candidates:
        if (root / "config/settings.yml").exists():
            return root
    raise FileNotFoundError("Cannot locate config/settings.yml")


def read_sql(relative_path: str, root: Path | None = None) -> str:
    base = root or project_root()
    path = (base / relative_path).resolve()
    if not path.is_relative_to(base.resolve()):
        raise ValueError("SQL path escapes project root")
    return path.read_text(encoding="utf-8").strip()


def render_sql(statement: str, db: DatabricksSettings) -> str:
    """Replace ONLY validated SQL identifiers (never user data values)."""
    values = {"catalog": f"`{db.catalog}`", "schema": f"`{db.schema}`"}
    result = _TEMPLATE.sub(lambda match: values[match.group(1)], statement)
    if "{{" in result or "}}" in result:
        raise ValueError("Unknown SQL template placeholder")
    return result


def statement_sql(relative_path: str, db: DatabricksSettings,
                  root: Path | None = None) -> str:
    return render_sql(read_sql(relative_path, root), db).rstrip("; ")


def fetch_json(url: str, *, payload: dict | None = None,
               token: str | None = None, timeout: int = 25) -> dict:
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    if data is not None:
        headers["Content-Type"] = "application/json"
    with urlopen(Request(url, data=data, headers=headers), timeout=timeout) as response:
        return json.load(response)


def execute_statement(host: str, token: str, warehouse_id: str,
                      statement: str, parameters: list[dict]) -> None:
    """Use the Statement Execution API; fail on SQL errors, don't log tokens."""
    if not host:
        raise ValueError("DATABRICKS_HOST is required")
    base = (host if host.startswith("https://") else "https://" + host).rstrip("/")
    endpoint = f"{base}/api/2.0/sql/statements"
    payload = {
        "warehouse_id": warehouse_id,
        "statement": statement,
        "parameters": parameters,
        "wait_timeout": "30s",
    }
    result = fetch_json(endpoint, payload=payload, token=token)
    for _ in range(45):
        state = result.get("status", {}).get("state")
        if state == "SUCCEEDED":
            return
        if state in {"FAILED", "CANCELED", "CLOSED"}:
            raise RuntimeError(f"Databricks SQL statement {state}: {result.get('status')}")
        statement_id = result.get("statement_id")
        if not statement_id:
            raise RuntimeError(f"Statement Execution API returned no statement_id: {result}")
        time.sleep(2)
        result = fetch_json(f"{endpoint}/{statement_id}", token=token)
    raise TimeoutError("Databricks SQL statement did not finish")
