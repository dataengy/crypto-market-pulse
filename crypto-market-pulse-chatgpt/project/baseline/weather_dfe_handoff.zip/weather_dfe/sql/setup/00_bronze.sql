CREATE SCHEMA IF NOT EXISTS {{catalog}}.{{schema}};

CREATE TABLE IF NOT EXISTS {{catalog}}.{{schema}}.weather_raw (
  event_id STRING,
  city STRING,
  observed_at TIMESTAMP,
  ingested_at TIMESTAMP,
  temp_c DOUBLE,
  humidity_pct DOUBLE,
  wind_kmh DOUBLE,
  source STRING
) USING DELTA;
