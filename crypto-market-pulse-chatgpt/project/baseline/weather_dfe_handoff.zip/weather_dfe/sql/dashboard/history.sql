-- Source of truth for the dashboard query. build_dashboard.py embeds it in JSON.
SELECT ingested_at, observed_at, city, temp_c, humidity_pct, wind_kmh, source
FROM {{catalog}}.{{schema}}.weather_silver
ORDER BY ingested_at DESC
LIMIT 500;
