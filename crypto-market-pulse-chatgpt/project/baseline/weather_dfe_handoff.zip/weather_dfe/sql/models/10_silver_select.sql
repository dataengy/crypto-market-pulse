-- Canonical, portable Spark SQL and DuckDB expression for the Silver layer.
-- The placeholder is substituted with a trusted table identifier by the build tools.
SELECT
  event_id, city, observed_at, ingested_at,
  temp_c, humidity_pct, wind_kmh, source
FROM {{source}}
WHERE city IS NOT NULL
  AND temp_c BETWEEN -100 AND 70
  AND humidity_pct BETWEEN 0 AND 100
  AND wind_kmh >= 0
