-- Canonical Gold transformation. Deterministic tie-breaking.
SELECT event_id, city, observed_at, ingested_at,
       temp_c, humidity_pct, wind_kmh, source
FROM (
  SELECT *, ROW_NUMBER() OVER (
    PARTITION BY city
    ORDER BY observed_at DESC, ingested_at DESC, event_id DESC
  ) AS rn
  FROM {{source}}
) AS ranked
WHERE rn = 1
