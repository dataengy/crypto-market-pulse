INSERT INTO {{catalog}}.{{schema}}.weather_raw (
  event_id, city, observed_at, ingested_at,
  temp_c, humidity_pct, wind_kmh, source
)
VALUES (
  :event_id, :city, CAST(:observed_at AS TIMESTAMP), current_timestamp(),
  :temp_c, :humidity_pct, :wind_kmh, :source
);
