# Databricks notebook source
# COMMAND ----------
# MAGIC %pip install "PyYAML>=6.0,<7.0"
# COMMAND ----------
from pathlib import Path
import sys

roots = [Path.cwd(), *Path.cwd().parents]
ROOT = next((p for p in roots if (p / "config/settings.yml").exists()), None)
if ROOT is None:
    raise FileNotFoundError("Open this notebook inside the deployed Git/bundle project")
sys.path.insert(0, str(ROOT / "src"))

from weather.settings import DatabricksSettings, load_settings, validate_identifier
from weather.utils import read_sql, render_sql

config = load_settings(ROOT / "config/settings.yml")
dbutils.widgets.text("catalog", config.databricks.catalog)
dbutils.widgets.text("schema", config.databricks.schema)
settings = DatabricksSettings(
    validate_identifier(dbutils.widgets.get("catalog")),
    validate_identifier(dbutils.widgets.get("schema")),
)

# The DDL stays in sql/setup/00_bronze.sql.
for sql in render_sql(read_sql("sql/setup/00_bronze.sql", ROOT), settings).split(";"):
    if sql.strip():
        spark.sql(sql.strip())
print("Bronze table ready:", settings.raw_table)
