# Databricks notebook source
# COMMAND ----------
# MAGIC %pip install "PyYAML>=6.0,<7.0"
# COMMAND ----------
import math
from pathlib import Path
import sys
import time
from datetime import datetime, timezone
import uuid

ROOT = next((p for p in [Path.cwd(), *Path.cwd().parents]
             if (p / "config/settings.yml").exists()), None)
if ROOT is None:
    raise FileNotFoundError("Open this notebook inside the deployed Git/bundle project")
sys.path.insert(0, str(ROOT / "src"))
from weather.settings import DatabricksSettings, load_settings, validate_identifier
from weather.utils import statement_sql

config = load_settings(ROOT / "config/settings.yml")
dbutils.widgets.text("catalog", config.databricks.catalog)
dbutils.widgets.text("schema", config.databricks.schema)
dbutils.widgets.text("events", str(config.weather.demo_events))
dbutils.widgets.text("interval_seconds", str(config.weather.demo_interval_seconds))
db = DatabricksSettings(
    validate_identifier(dbutils.widgets.get("catalog")),
    validate_identifier(dbutils.widgets.get("schema")),
)
insert_sql = statement_sql("sql/ingestion/insert_weather.sql", db, ROOT)
events = int(dbutils.widgets.get("events"))
interval = float(dbutils.widgets.get("interval_seconds"))
assert 0 < events <= 300 and 0 < interval <= 3600

for i in range(events):
    record = {
        "event_id": str(uuid.uuid4()), "city": config.weather.city,
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "temp_c": float(round(19 + 2.5 * math.sin(i / 3), 2)),
        "humidity_pct": float(71 + i % 10),
        "wind_kmh": float(12 + i % 7),
        "source": "simulated",
    }
    # SQL text is loaded from a .sql file. Values are bound parameters.
    spark.sql(insert_sql, args=record)
    print(f"#{i + 1}: {record['temp_c']} °C")
    if i + 1 < events:
        time.sleep(interval)
