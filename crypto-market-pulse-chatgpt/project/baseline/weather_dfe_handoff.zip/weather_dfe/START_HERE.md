# Weather DFE: integrated source + three-profile handoff

This handoff **contains source and drafts**, not a validated multi-profile deployment.

**Start here:** `docs/CLAUDE_CODE_WEATHER_DFE_PROMPT.md`, then `docs/WEATHER_DFE_MULTI_PROFILE_SPEC.md` and `docs/local/LOCAL_RUNTIME_REUSE_POLICY.md`.

- `README.md` / existing `src/`, `sql/`, `notebooks/`, `dashboards/`, `config/`, `.github/`, `scripts/` are the **unchanged Weather DFE v3 baseline**, except the new discovery script and its tests.
- `baseline/weather_dfe_v3.zip` is the original v3 ZIP; `baseline/weather_dfe_all_gen_v3.py` reproduces the v3 baseline (not the updated handoff).
- `docs/local/CLICKHOUSE_LOCAL_DEBUG.md` & `docs/local/GCP_LOCAL_DEBUG.md`: draft architecture/debug steps.
- `drafts/clickhouse/` & `drafts/gcp/`: illustrative SQL and Beam test, **not connected to just/CI yet**.
- `scripts/discover_local_runtime.py`: read-only local inventory; **run before any new installation or container startup**.
- `tests/test_discover_local_runtime.py`: unit tests for inventory scanning.

On macOS, extract this ZIP under a *new directory*, inspect current repo with `git status` before copying, and never overwrite an existing tracked file without diff/backup. No changes have been pushed to GitHub.

## Fast non-mutating checks

```bash
python3 scripts/discover_local_runtime.py --markdown
python3 -m unittest discover -s tests -p 'test_discover_local_runtime.py' -v
```

## Priority reminder

1. Existing OS-installed applications in `PATH`, `~/.apps/`, `~/.app/`.
2. Existing Docker/Colima containers, then cached images.
3. New installation/container **only if unavoidable**.

Never stop/remove or reconfigure other projects' services.
