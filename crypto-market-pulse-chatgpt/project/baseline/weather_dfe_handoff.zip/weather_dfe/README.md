# Weather DFE — SQL-first Streaming + local Spark + MiniLake (v3)

Educational streaming weather mart, with production-style separation of SQL, Python,
config, notebooks, dashboard and deployment files. **Databricks Free Edition (DFE)
is for non-commercial experimentation and has compute/network restrictions.**

```text
Open-Meteo / synthetic events
  └─ producer: GitHub Actions every ~5 min / notebook demo every 10 s
       └─ Delta bronze: weather_raw
            └─ continuous Lakeflow SQL: weather_silver (streaming)
                 └─ Lakeflow SQL: weather_latest (materialized view)
                      └─ AI/BI Lakeview dashboard as code
```

Real Open-Meteo readings may only change on the provider's update cadence.
The *Spark pipeline* can consume newly arriving records frequently, but a
GitHub Actions cron job is not a precise 5-minute streaming event producer.
Dashboard charts refresh separately and are not pushed via a websocket.

## Why two local test lanes?

**`local_spark_debug.py`** runs **real Spark 4 Structured Streaming** over a
file source with `AvailableNow`, two batches, durable checkpoint, `foreachBatch`,
and Spark SQL Gold snapshots. It runs the **same SELECT models** as Databricks
via `sql/models/*.sql`. The local sink uses Parquet to avoid native/cloud-specific
Unity Catalog and Delta setup; it tests streaming offsets, Spark parsing and
model outputs but **not the exact Lakeflow runtime or Delta source**.

**MiniLake** at `localhost:8000` simulates Databricks SDK, Unity Catalog and SQL
warehouse APIs, with **real DuckDB SQL**. `scripts/minilake_smoke.py` creates
isolated fixture tables via SDK, applies the SAME SQL SELECT models and checks
results. However **MiniLake does NOT implement Lakeflow/DLT or Lakeview**;
`CREATE OR REFRESH STREAMING TABLE` and `.lvdash.json` are tested/deployed only
in actual Databricks. MiniLake does not enforce real IAM permissions. It must
never be publicly exposed. See https://dmux.github.io/minilake/.

## Layout

```text
config/settings.yml                App defaults
src/weather/settings.py           Typed settings and validation
src/weather/utils.py              Request/Databricks SQL helpers
src/weather/collector.py          API producer (no inline SQL)
sql/models/*_select.sql           Canonical Silver & Gold SELECT models
scripts/build_pipeline_sql.py     Generates Databricks Lakeflow wrappers
sql/pipelines/*.sql               Generated, Git-tracked Lakeflow streaming SQL
sql/setup/00_bronze.sql           Delta bronze DDL
sql/ingestion/insert_weather.sql  Parameterized ingestion
sql/dashboard/history.sql         Source for dashboard query
scripts/build_dashboard.py        Generates dashboard JSON
scripts/local_spark_debug.py      Local REAL Structured Streaming runner
scripts/minilake_smoke.py         Optional Databricks SDK/MiniLake API test
notebooks/                        DFE setup + demo events
databricks.yml                    Declarative Automation Bundle (DFE)
docker-compose.minilake.yml       Local MiniLake only (bind 127.0.0.1)
.github/workflows/ci.yml          Unit + actual local Spark tests
.github/workflows/minilake.yml    Optional manual MiniLake integration
.github/workflows/weather_collector.yml  5-minute external polling
```

**SQL is the source of truth:** edit `sql/models/*.sql`, run
`python scripts/build_pipeline_sql.py`, and commit both source and generated
files. The builder switches only the trusted source table name: local Spark
uses `weather_raw`, MiniLake uses `catalog.schema.weather_raw`, Databricks
uses `STREAM(${weather.raw_table})`. Gold remains materialized as a MV in DFE.

## A. Fastest local checks (no cloud)

Python 3.11 recommended:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/build_pipeline_sql.py
python scripts/build_dashboard.py
PYTHONPATH=src python -m unittest discover -s tests -v
```

### Real local Spark Structured Streaming

Requires Java 17 or newer, Python 3.11, and PySpark 4.0.1:

```bash
pip install -r requirements-dev.txt
java -version
python scripts/local_spark_debug.py
```

Expected assertion: latest observation `Batumi=19.0` and `Warsaw=10.0`.
The fourth event (`Batumi=999`) is rejected by canonical Silver SQL rules.
The script creates a temporary input, checkpoint and Parquet output, then
cleans them. For inspecting files after execution:

```bash
WEATHER_LOCAL_WORK_DIR="$PWD/local-data" python scripts/local_spark_debug.py
```

Spark may need `SPARK_LOCAL_IP=127.0.0.1` on laptops with unusual hostname resolution.
On Apple Silicon, install a compatible ARM64 Java distribution (e.g. Temurin 17).
For step-through debugging, open `scripts/local_spark_debug.py` in PyCharm,
set a breakpoint in `process_batch`, and run it as a Python script.

### MiniLake SDK / SQL integration (optional)

Requires Docker Desktop/Colima and the `databricks-sdk`. Published container
tag pinned to **1.8.0**; the site may document newer releases.

```bash
pip install -r requirements-minilake.txt
docker compose -f docker-compose.minilake.yml up -d
curl --fail http://localhost:8000/ready
python scripts/minilake_smoke.py
# optional MiniLake SQL UI: http://localhost:8000/ui/
docker compose -f docker-compose.minilake.yml down
```

MiniLake only runs on `127.0.0.1`. Its local credential is a dummy token. The
smoke test deliberately refuses to connect to any non-localhost hostname.
Not a replacement for the Spark streaming test, Delta end-to-end test or DFE.

## B. Deploy to Databricks Free Edition

1. Import/open this Git folder in the DFE workspace, or use the Databricks CLI.
2. Open/run `notebooks/00_setup.py` **once** to create the Delta Bronze table.
3. Configure CLI authentication, select an existing SQL warehouse ID.
4. Deploy and run (the pipeline is configured to run continuously):

```bash
databricks auth login --host https://YOUR-WORKSPACE-HOST
databricks bundle validate --var 'warehouse_id=YOUR_SQL_WAREHOUSE_ID'
databricks bundle deploy --var 'warehouse_id=YOUR_SQL_WAREHOUSE_ID'
databricks bundle run weather_stream --var 'warehouse_id=YOUR_SQL_WAREHOUSE_ID'
```

5. Run `notebooks/01_demo_producer.py` for 10-second synthetic events, inspect
`workspace.weather_demo.weather_silver` and `.weather_latest`, and open the
AI/BI dashboard. **Stop the continuous pipeline after the demo** — DFE
compute quotas apply. If you change `catalog` / `schema` in Bundle variables,
update the app config (or matching environment overrides) as well.

6. For optional real weather in GitHub Actions, set `DATABRICKS_HOST`,
`DATABRICKS_TOKEN`, `DATABRICKS_WAREHOUSE_ID` as secrets (never commit tokens).
Ensure your DFE account supports the selected automation credential and API
access. Set optional repo variables `DATABRICKS_CATALOG` / `DATABRICKS_SCHEMA`.
The scheduled workflow is separate from CI and may need manually enabling
Actions on a new repository. GitHub cron delivery is best effort.

### Cloud validation boundary

Unit and local Spark tests confirm the portable SQL model and basic streaming
semantics. They do **not** validate DFE deployment, Unity Catalog grants,
Delta streaming concurrency, continuous-pipeline availability, or dashboard
import/visual rendering. Validate those in a live workspace before claiming an
end-to-end result.

## C. CI

- `.github/workflows/ci.yml` on every push/PR: Python compilation, 9+ unit
  tests, generator drift check, **real PySpark Structured Streaming** test
  using Java 17 and Python 3.11. No Databricks credentials required.
- `.github/workflows/minilake.yml` on **manual workflow_dispatch**: Dockerized
  API emulator and SQL model smoke test. Deliberately optional because it
  depends on a separate image, whose API and tests may differ by release.
- `.github/workflows/weather_collector.yml`: **not CI**, a scheduled 5-minute
  producer, only useful after configuring actual Databricks access/secrets.

Optional commands with `just` (`brew install just`): `just build`, `just unit`,
`just spark`, `just minilake-up`, `just minilake-test`, `just minilake-down`.

References: [MiniLake](https://dmux.github.io/minilake/),
[Databricks Free Edition limits](https://docs.databricks.com/gcp/en/getting-started/free-edition-limitations),
[Databricks Lakeflow](https://docs.databricks.com/gcp/en/ldp/),
[Dashboard as code](https://docs.databricks.com/gcp/en/dashboards/automate/).
