#!/usr/bin/env python3
"""Generate Databricks Lakeview JSON from sql/dashboard/history.sql."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from weather.settings import load_settings
from weather.utils import statement_sql


def build_dashboard() -> dict:
    config = load_settings(ROOT / "config/settings.yml")
    query = statement_sql("sql/dashboard/history.sql", config.databricks, ROOT)
    dataset = {"name": "weather_history", "displayName": "Weather history", "query": query}

    def chart(key: str, title: str, x: int, y: int, width: int):
        return {
            "widget": {
                "name": f"{key}_chart",
                "queries": [{
                    "name": "main_query",
                    "query": {
                        "datasetName": dataset["name"],
                        "fields": [
                            {"name": "ingested_at", "expression": "`ingested_at`"},
                            {"name": key, "expression": f"`{key}`"},
                        ],
                        "disaggregated": True,
                    },
                }],
                "spec": {
                    "version": 3, "widgetType": "line",
                    "encodings": {
                        "x": {"fieldName": "ingested_at", "scale": {"type": "temporal"}},
                        "y": {"fieldName": key, "scale": {"type": "quantitative"}},
                    },
                    "frame": {"title": title, "showTitle": True},
                },
            },
            "position": {"x": x, "y": y, "width": width, "height": 6},
        }

    return {
        "datasets": [dataset],
        "pages": [{
            "name": "weather_page", "displayName": "Weather · " + config.weather.city,
            "pageType": "PAGE_TYPE_CANVAS",
            "layout": [
                chart("temp_c", "Temperature (°C)", 0, 0, 12),
                chart("humidity_pct", "Humidity (%)", 0, 6, 6),
                chart("wind_kmh", "Wind (km/h)", 6, 6, 6),
            ],
        }],
    }


def main() -> None:
    target = ROOT / "dashboards/weather.lvdash.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(build_dashboard(), indent=2, ensure_ascii=False) + "\n",
                      encoding="utf-8")
    print(f"Generated {target}")


if __name__ == "__main__":
    main()
