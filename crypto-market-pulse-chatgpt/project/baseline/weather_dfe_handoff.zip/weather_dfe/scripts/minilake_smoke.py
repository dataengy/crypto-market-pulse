#!/usr/bin/env python3
"""MiniLake integration smoke: real SDK, SQL execution, shared SQL models.

NOT a substitute for Lakeflow streaming, Lakeview dashboards, Delta writes or
permissions. MiniLake executes these SELECT queries with DuckDB SQL semantics.
"""
from __future__ import annotations

import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from weather.settings import validate_identifier
from build_pipeline_sql import model_sql


def run() -> None:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.catalog import ColumnInfo, TableType

    host = os.environ.get("MINILAKE_HOST", "http://localhost:8000")
    # Never point this deliberately unauthenticated smoke test at real Databricks.
    if not (host.startswith("http://localhost:") or host.startswith("http://127.0.0.1:")):
        raise ValueError("MiniLake smoke runs only against localhost")
    w = WorkspaceClient(host=host, token="local-dev")
    catalog = validate_identifier(os.environ.get("MINILAKE_CATALOG", "weatherci"))
    schema = validate_identifier(os.environ.get("MINILAKE_SCHEMA", "weather"))
    try:
        w.catalogs.create(name=catalog)
    except Exception as e:
        if "already exists" not in str(e).lower():
            raise
    try:
        w.schemas.create(name=schema, catalog_name=catalog)
    except Exception as e:
        if "already exists" not in str(e).lower():
            raise
    warehouse = w.warehouses.create(name="weather-local", cluster_size="Small")
    qualified_raw = f"{catalog}.{schema}.weather_raw"
    qualified_silver = f"{catalog}.{schema}.weather_silver"
    cols = [
        ColumnInfo(name=k, type_text=t)
        for k, t in (
            ("event_id", "STRING"), ("city", "STRING"),
            ("observed_at", "STRING"), ("ingested_at", "STRING"),
            ("temp_c", "DOUBLE"), ("humidity_pct", "DOUBLE"),
            ("wind_kmh", "DOUBLE"), ("source", "STRING"),
        )
    ]
    w.tables.create(
        name="weather_raw", catalog_name=catalog, schema_name=schema,
        table_type=TableType.MANAGED, data_source_format="DELTA", columns=cols,
    )

    def execute(sql: str):
        res = w.statement_execution.execute_statement(
            warehouse_id=warehouse.id, statement=sql, wait_timeout="30s"
        )
        if not res.status or str(res.status.state).split(".")[-1] != "SUCCEEDED":
            raise RuntimeError(f"MiniLake statement failed: {res.status}")
        return res

    execute(f"INSERT INTO {qualified_raw} VALUES "
            "('1','Batumi','2026-10-27T12:00:00Z','2026-10-27T12:01:00Z',17,70,5,'demo'),"
            "('2','Warsaw','2026-10-27T12:00:00Z','2026-10-27T12:01:00Z',10,70,5,'demo'),"
            "('3','Batumi','2026-10-27T12:05:00Z','2026-10-27T12:06:00Z',19,70,5,'demo'),"
            "('4','Batumi','2026-10-27T12:06:00Z','2026-10-27T12:07:00Z',999,70,5,'demo')")
    silver = model_sql("10_silver", qualified_raw)
    gold = model_sql("20_gold", qualified_silver)
    execute(f"CREATE VIEW {qualified_silver} AS {silver}")
    result = execute(f"SELECT city, temp_c FROM ({gold}) AS gold ORDER BY city")
    rows = result.result.data_array if result.result else []
    assert rows and [(r[0], float(r[1])) for r in rows] == [
        ("Batumi", 19.0), ("Warsaw", 10.0)
    ], rows
    print(f"MiniLake SDK + SQL SELECT smoke PASS: {rows}")


if __name__ == "__main__":
    run()
