#!/usr/bin/env python3
"""Exercise the real Spark Structured Streaming micro-batch engine locally.

Uses the EXACT model SELECT SQL consumed by the Lakeflow SQL generator. The
local source/sink are JSON/Parquet, not Delta or Unity Catalog, deliberately.
Spark 4.x + Java 17+ is required. No Databricks account, Minilake or API calls.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from build_pipeline_sql import model_sql


def _row(i: int, city: str, temp: float, observed_at: str) -> dict:
    return {
        "event_id": f"demo-{i}",
        "city": city,
        "observed_at": observed_at,
        "ingested_at": "2026-10-27T12:01:00Z",
        "temp_c": temp,
        "humidity_pct": 70.0,
        "wind_kmh": 5.0,
        "source": "local-synthetic",
    }


def run(work_dir: Path | None = None) -> dict:
    from pyspark.sql import SparkSession, types as T

    spark = (SparkSession.builder.master("local[2]")
             .appName("weather-dfe-structured-stream-debug")
             .config("spark.sql.shuffle.partitions", "2")
             .config("spark.ui.enabled", "false")
             .getOrCreate())
    spark.sparkContext.setLogLevel("ERROR")

    # Fixed schema: do not infer a streaming schema from mutable input files.
    schema = T.StructType([
        T.StructField("event_id", T.StringType()),
        T.StructField("city", T.StringType()),
        T.StructField("observed_at", T.StringType()),
        T.StructField("ingested_at", T.StringType()),
        T.StructField("temp_c", T.DoubleType()),
        T.StructField("humidity_pct", T.DoubleType()),
        T.StructField("wind_kmh", T.DoubleType()),
        T.StructField("source", T.StringType()),
    ])
    owned = work_dir is None
    work = Path(tempfile.mkdtemp(prefix="weather_spark_")) if owned else Path(work_dir)
    incoming = work / "incoming"
    silver_path = work / "silver"
    gold_path = work / "gold"
    checkpoint = work / "checkpoint"
    incoming.mkdir(parents=True, exist_ok=True)

    silver_sql = model_sql("10_silver", "weather_raw")
    gold_sql = model_sql("20_gold", "weather_silver")

    def process_batch(batch, batch_id):
        # foreachBatch is intentionally an imperative LOCAL testing adapter.
        # Production Lakeflow uses generated CREATE STREAMING TABLE / MV SQL.
        batch.createOrReplaceTempView("weather_raw")
        clean = spark.sql(silver_sql)
        if clean.limit(1).count() == 0:
            return
        clean.write.mode("append").parquet(str(silver_path))
        history = spark.read.parquet(str(silver_path))
        history.createOrReplaceTempView("weather_silver")
        latest = spark.sql(gold_sql)
        latest.write.mode("overwrite").parquet(str(gold_path))
        print(f"Batch {batch_id}: {clean.count()} valid rows, latest by city:")
        latest.select("city", "temp_c", "observed_at").show(truncate=False)

    try:
        # Two independent files = two real streaming source offsets, using one
        # persistent checkpoint across the two AvailableNow executions.
        chunks = [
            [_row(1, "Batumi", 17.0, "2026-10-27T12:00:00Z"),
             _row(2, "Warsaw", 10.0, "2026-10-27T12:00:00Z")],
            [_row(3, "Batumi", 19.0, "2026-10-27T12:05:00Z"),
             _row(4, "Batumi", 999.0, "2026-10-27T12:06:00Z")],
        ]
        for i, rows in enumerate(chunks):
            (incoming / f"events_{i:02d}.json").write_text(
                "".join(json.dumps(r) + "\n" for r in rows), encoding="utf-8"
            )
            input_df = spark.readStream.schema(schema).json(str(incoming))
            query = (input_df.writeStream
                     .foreachBatch(process_batch)
                     .option("checkpointLocation", str(checkpoint))
                     .trigger(availableNow=True)
                     .start())
            query.awaitTermination(120)
            if query.isActive:
                query.stop()
                raise TimeoutError("Local micro-batch did not finish")
            if query.exception() is not None:
                raise RuntimeError(f"Spark streaming failed: {query.exception()}")

        results = {r["city"]: r["temp_c"]
                   for r in spark.read.parquet(str(gold_path)).collect()}
        if results != {"Batumi": 19.0, "Warsaw": 10.0}:
            raise AssertionError(f"Unexpected local Gold snapshot: {results}")
        print("PASS: source offsets/checkpoint, two batches, validation, latest Gold", results)
        return results
    finally:
        spark.stop()
        if owned:
            shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    run(Path(os.environ["WEATHER_LOCAL_WORK_DIR"]) if os.environ.get("WEATHER_LOCAL_WORK_DIR") else None)
