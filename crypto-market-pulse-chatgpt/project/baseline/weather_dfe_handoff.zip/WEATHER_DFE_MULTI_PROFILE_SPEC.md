# Weather DFE — multi-profile streaming MVP (technical specification)

**Status:** implementation specification, NOT a claim of deployment or CI success.  
**Updated:** 2026-10-30.  
**Target repository:** determine the canonical repository and authenticated GitHub identity before making changes; intended names mentioned in project history: `beloz978/weather_dfe` and `dataengy/weather_dfe`. Never archive, fork, force-push, or change remotes without a separate, explicit instruction and successful read-only validation.  
**Baseline:** use `weather_dfe_v3.zip` / `weather_dfe_all_gen_v3.py` from the preceding ChatGPT deliverable as input if no usable code exists in the local checkout. Preserve existing v3 SQL-first Databricks DFE, notebooks, local PySpark, MiniLake, and CI behavior.


## Mandatory local-first dependency reuse (applies to ALL profiles and CI planning)

**Priority is strict:** (1) already-installed **host/OS applications** and binaries, including `PATH`, `~/.apps/`, `~/.app/`; (2) **existing** containers/images and active runtimes in Docker Desktop / Colima; (3) only if both unsuitable, install or launch new project-owned components. For ClickHouse, Redpanda/Kafka, Spark/PySpark, PostgreSQL, MiniLake, Airbyte and **all supporting tooling**, run `python3 scripts/discover_local_runtime.py --markdown` first and capture a compatibility/ownership decision. See [`docs/local/LOCAL_RUNTIME_REUSE_POLICY.md`](local/LOCAL_RUNTIME_REUSE_POLICY.md) for full requirements, rollback constraints, non-destructive reuse and acceptance criteria. Do not confuse inventory with consent to start/stop/modify a shared service.

**Mandatory draft plans:** [`docs/local/CLICKHOUSE_LOCAL_DEBUG.md`](local/CLICKHOUSE_LOCAL_DEBUG.md) and [`docs/local/GCP_LOCAL_DEBUG.md`](local/GCP_LOCAL_DEBUG.md). These are designs and example tests, not claims of passing production integrations. **Local reruns must not create duplicate containers or delete shared resources.** If a service is missing, explain the discovery evidence before falling back to a new image or installation.

## 1. Goal

Build **three independently selectable deployment profiles**, demonstrating equivalent weather-domain semantics across three streaming stacks:

| Profile name | Local pipeline and debugging | Hosted ingestion, streaming and DWH | Dashboard |
|---|---|---|---|
| `databricks` (existing) | PySpark Structured Streaming; MiniLake for SDK/SQL smoke only | Databricks Free Edition: Delta Bronze -> Lakeflow SQL Silver -> Gold | Databricks AI/BI dashboard-as-code |
| `clickhouse` (new) | Redpanda broker/Console + ClickHouse OSS in Docker Compose | **Confluent Cloud Basic on GCP** (managed Kafka, preferably colocated with ClickHouse Cloud region) -> ClickHouse Cloud **ClickPipes Kafka** -> ClickHouse SQL MV/views | Lightweight SQL-driven dashboard-as-code (Evidence/Metabase-as-code or a minimal checked-in web dashboard; select ONE with working setup) |
| `gcp` (new) | Apache Beam **DirectRunner + TestStream** for event-time logic; Pub/Sub Emulator for publisher/subscriber client tests; local SQL model tests on DuckDB, explicitly non-identical to BigQuery | **MVP:** Pub/Sub -> native BigQuery Subscription -> BigQuery raw table -> BigQuery SQL views. **Advanced:** Pub/Sub -> Apache Beam on **Dataflow** -> BigQuery -> same semantic mart | BigQuery-connected Looker Studio if scripted import is impractical, or **Evidence** dashboard-as-code (preferred for fully reproducible Git versioning); document limitations |

Use Confluent Cloud Basic instead of operating Kafka on GKE/GCE or AWS MSK; private networking/managed service complexity is intentionally out of initial scope. Redpanda provides Kafka API compatibility on the laptop. Alternative Redpanda Cloud is **not** required for v1.

## 2. Shared, engine-neutral domain contract

In `src/weather/domain.py` and `docs/event_contract.md`, define one versioned JSON event contract (plus a small JSON Schema) shared by all profiles:

```json
{
  "schema_version": 1,
  "event_id": "<deterministic identifier>",
  "source": "open-meteo",
  "city": "Batumi",
  "observed_at": "2026-10-30T10:00:00Z",
  "collected_at": "2026-10-30T10:00:12Z",
  "temp_c": 19.2,
  "humidity_pct": 73,
  "wind_kmh": 12.4,
  "mode": "real"
}
```

- `observed_at` = **provider observation/event time** in UTC; `collected_at` = poll/producer time, not a fabricated new observation timestamp.
- `event_id` deterministic from provider identity, city, observation time and revision/content. Define a separate `observation_key = (source, city, observed_at)` to support corrections and repeated API polling. Specify deterministic latest-revision tie-break rules.
- Validate typed fields, `humidity_pct` 0..100, plausible temperature, timestamp UTC and reasonable null-handling.
- **Do not generate false real-weather data every 10 seconds**: real producer defaults to poll every 5 minutes and emits only changed provider observations (or uses idempotent event IDs). Synthetic `demo` events may be emitted every 10 seconds for streaming latency demos, clearly tagged `mode=demo` and isolated/filtered from production dashboards.
- Keep sample fixture files under `tests/fixtures/` for Batumi, Warsaw and optionally Las Palmas; include duplicates, out-of-order, late, invalid, source correction and retry cases.
- Define consistent SQL mart interfaces across engines (same columns and meaning, not necessarily identical SQL dialect):
  - `weather_raw` — append-only ingestion, provenance and timestamps.
  - `weather_silver` — validated canonical observations / deterministic dedup.
  - `weather_latest` — one latest valid observation per city/source/mode.
  - `weather_1m` — 1-minute event-time buckets with `count`, `avg_temp_c`, `min_temp_c`, `max_temp_c`, `avg_wind_kmh` (and window completeness guidance).
- The three engines may apply different physical plans (views, materialized views, streaming transforms). **Do not promise identical exactly-once behavior**; specify the observed behavior, offset/checkpoint ownership and deduplication scope.
- SQL must live in versioned `.sql` files, partitioned by dialect (`sql/common` only for truly portable SQL, `sql/clickhouse`, `sql/bigquery`, `sql/databricks`); no long embedded SQL literals in Python. Use golden-fixture tests comparing logical results, not a claim of universal SQL portability.

## 3. Profile `clickhouse`

### 3.1 Local mode (mandatory)

```text
Open-Meteo / synthetic Python producer
    -> Redpanda single broker (Kafka-compatible) + Redpanda Console
    -> Python Kafka consumer / lightweight ingest adapter
    -> ClickHouse OSS (raw MergeTree)
    -> SQL materialized views / latest & 1m SELECTs
    -> dashboard
```

- Docker Compose fallback only **after checking installed host Redpanda/Kafka and existing Docker/Colima containers**; otherwise create single-broker Redpanda + Console with explicit dual advertised listeners for host and Docker network. Pin images; avoid `latest`.
- Use `confluent-kafka` Python producer for **both** local Redpanda and managed Confluent, changing only configuration and credentials. Define partition key by `city`; configure delivery callbacks, retries and producer `flush` behavior, no silent drops.
- Configure topic `weather.observations.v1`, retention defaults, partitions (start at 1 or 3 for demo), schema/versioning, and simple DLQ for rejected records.
- Implement local Kafka -> CH sink as a small **debug adapter**, not a fake ClickPipes emulator. It should batch inserts into ClickHouse OSS, commit Kafka offsets **only after successful sink writes**, and be restartable. Tests must cover duplicate delivery and crash before offset commit.
- CH `weather_raw` append-only `MergeTree` with explicit order/partition keys; `ReplacingMergeTree` is an optional variant **not a guarantee of immediate physical deduplication**. Use explicit `argMax`/`row_number` semantics or deduped views for deterministic query results. CH materialized views operate on inserted blocks: don't assume deduplication of historical data magically propagates into downstream MVs.
- `weather_1m` preferably via `AggregatingMergeTree` + aggregate state functions (or a simpler SQL view first), with documented backfill and replay strategy.
- `just local-inventory`, `just clickhouse-up`, `just clickhouse-produce-demo`, `just clickhouse-test`, `just clickhouse-down`.

### 3.2 Cloud mode (mandatory)

```text
producer -> Confluent Cloud Basic (GCP region) -> ClickPipes (Kafka source)
         -> ClickHouse Cloud raw table -> ClickHouse SQL marts -> dashboard
```

- Choose region after checking both Confluent and ClickHouse Cloud availability; colocate to reduce egress/latency. Don't hardcode a guessed region.
- Provide IaC (Terraform where supported) for ClickHouse database/tables, managed Kafka topic, ClickPipe; document one-off API keys and any resources that genuinely require an initial console step. Do not store credentials in the repo. Use least privilege and `.env.example` with fake placeholders only.
- ClickPipes is **at-least-once by default**; document its optional exactly-once mode and caveat that the ClickHouse deduplication-token window is bounded. Always implement a deterministic `weather_latest` even if transport dedup is enabled.
- Cloud smoke: deliver 3 unique and 2 repeated events, verify raw ingestion, latest mart, 1m aggregation, event-time semantics, replay, and capture time-to-visibility. Clean up optional paid resources afterward.
- Cloud test **manual/opt-in** to prevent accidental charges; never invoke by default in PR CI.

## 4. Profile `gcp`

### 4.1 Minimal managed implementation (mandatory first)

```text
Cloud Scheduler (every 1–5 min) -> Cloud Run Job producer -> Pub/Sub
                         -> BigQuery Subscription -> BigQuery raw table
                         -> BigQuery SQL views (`weather_latest`, `weather_1m`)
                         -> dashboard
```

- Implement producer using shared domain normalization; use Cloud Run Job invoked by Cloud Scheduler with service-account identity (not long-lived service-account key JSON), Secret Manager only if required, least-privilege IAM and controlled timeout/retry policy.
- BigQuery Subscription minimizes infrastructure and is the correct **MVP** when raw events need no streaming transformation before BigQuery. Implement dead-letter topic, schema mapping and error handling.
- BigQuery Subscription uses **at-least-once** delivery; dedup at SQL layer using deterministic keys and `ROW_NUMBER() ... QUALIFY`; do not claim exactly-once.
- `weather_latest` should be a standard logical SQL view initially; materialized view is an explicit, separately validated optimization, **not automatically interchangeable** with arbitrary latest-row SQL. Document query cost and refresh effects.
- Native streaming means continuously arriving Pub/Sub records reach queryable BigQuery; the *weather API* cadence and dashboard refresh are separate clocks.
- IaC for Pub/Sub, BigQuery, Cloud Run, Cloud Scheduler, IAM, outputs. Don't auto-deploy paid GCP infrastructure from PRs.

### 4.2 Advanced Beam/Dataflow implementation (optional second phase, but scaffold and tests mandatory)

```text
Pub/Sub -> Beam parsing & validation -> event-time / late-data handling
        -> Dataflow streaming -> BigQuery silver/raw
        -> SQL marts in BigQuery
```

- Python Apache Beam module (reusable source in `src/weather/gcp/beam_pipeline.py`) with CLI runner switch `DirectRunner`/`DataflowRunner`.
- `TestStream` tests for out-of-order and late observations; explicit allowed lateness, watermark, triggering and window logic. Enforce deterministic event IDs and stream dedup assumptions.
- Side output invalid records to DLQ; prefer SQL views for latest/aggregation when they satisfy requirement, only use Beam windows when demonstrating genuine stream transformations.
- Document Dataflow worker/streaming job costs and provide explicit start/stop commands; do not leave a continuous job running after smoke testing.

### 4.3 Local GCP debugging (mandatory)

- `pytest` unit tests for parser/validation and SQL golden fixtures.
- Beam DirectRunner + **TestStream** for repeatable time/window behavior without credentials.
- Pub/Sub Emulator in Docker or `gcloud beta emulators pubsub start`; use `PUBSUB_EMULATOR_HOST` to test publisher/subscriber client and retry handling.
- **Important:** Pub/Sub Emulator does not actually deliver a BigQuery subscription into BigQuery. It cannot prove the cloud sink. For BigQuery correctness, use SQL fixture tests (DuckDB with explicit dialect adaptations where possible) and a separate manual, real BigQuery sandbox smoke run.
- Don't require BigQuery emulator or falsely claim that MiniLake emulates GCP. MiniLake remains restricted to the existing Databricks SDK/SQL lane.
- `just local-inventory`, `just gcp-unit`, `just gcp-beam-test`, `just gcp-emulator-up`, `just gcp-emulator-test`, `just gcp-emulator-down`, `just gcp-cloud-smoke`.

## 5. Configuration and separation of concerns

Proposed repo additions, retaining v3 artifacts:

```text
config/
  settings.yml                         # common app defaults, non-secret
  profiles/{databricks,clickhouse,gcp}.yml
src/weather/
  domain.py                            # canonical events and validation
  settings.py                          # typed settings, precedence/validation
  utils.py                             # pure helpers, no engine logic
  collector.py                         # shared Open-Meteo parser/fetcher
  publishers/{kafka,pubsub,databricks}.py
  clickhouse/{consumer,client}.py
  gcp/beam_pipeline.py
sql/
  models/                              # existing v3 portable SELECTs (retain)
  databricks/                          # existing generated pipeline SQL
  clickhouse/{ddl,views,marts}/
  bigquery/{ddl,views,marts}/
infra/
  clickhouse/docker-compose.yml
  clickhouse/terraform/
  gcp/docker-compose.pubsub.yml
  gcp/terraform/
dashboards/
  databricks/
  clickhouse/
  gcp/
tests/
  fixtures/
  unit/
  integration/{spark,redpanda_clickhouse,beam,pubsub_emulator,minilake}/
  cloud/                               # opt-in cloud smoke only
.github/workflows/
  ci.yml                               # offline, fast, required checks
  integration.yml                      # local Docker/Spark, PR or manual
  cloud-smoke.yml                      # manual, secrets, costs, cleanup
justfile                                # common profile commands
README.md
ARCHITECTURE.md
```

- Keep `settings.py` typed, zero side effects during import, fail fast on missing required **cloud** credentials, safe defaults for **local** profiles.
- Use precedence CLI > environment > profile YAML > common YAML. Never put tokens in YAML or `databricks.yml`, `.env.example` contains placeholders only.
- Make profile explicit (`WEATHER_PROFILE=databricks|clickhouse|gcp`); refuse cross-profile incompatible environment combinations.
- `utils.py` contains only reusable I/O-independent helpers; don't turn it into a dumping ground for SQL, networking, and credentials.
- Notebook tasks remain thin entrypoints; engines/SQL remain testable via ordinary Python modules, files and CI.

## 6. CI, local debug and acceptance

**Always-run PR CI:** Python compile + ruff + pytest; YAML/JSON checks; SQL file existence and render/generator drift checks; deterministic domain model fixtures; no cloud credentials, no paid resources.

**Integration CI:** Docker Redpanda+ClickHouse local e2e (health checks, retry limits and cleanup); Beam DirectRunner tests; Pub/Sub Emulator client smoke; Spark local stream; MiniLake separate optional test (remain non-equivalent to Databricks runtime).

**Manual cloud smoke:** separate opt-in jobs for `clickhouse` and `gcp`, protected GitHub Environments, no logging secrets, budget guards, explicit cleanup and documented expense. Use short-lived GCP auth via GitHub OIDC/Workload Identity Federation if available; Confluent/ClickHouse API keys only in repository secrets.

**Must pass:**
1. `just unit`: same shared JSON contract tests pass.
2. `just databricks-local-test`: existing v3 PySpark test still works.
3. `just clickhouse-local-test`: Redpanda -> CH raw -> latest/1m produces expected records; `docker compose down` cleans up safely.
4. `just gcp-beam-test`: `TestStream` demonstrates watermark/window/late-data handling with deterministic assertions.
5. `just gcp-emulator-test`: producer and subscriber client interact with Pub/Sub Emulator; does **not** claim BigQuery sink E2E.
6. Same fixture gives logically equivalent `weather_latest` and `weather_1m` across supported SQL dialects, with documented precision/timezone nuances.
7. Duplicate deliveries, replay, restart, invalid rows and out-of-order events are covered.
8. `just cloud-smoke PROFILE=clickhouse|gcp`: opt-in real cloud integration with evidence and teardown (mark skipped when credentials/resources absent, not green as if run).
9. Dashboard has code-controlled query, at least temperature, humidity, wind, history, city filter and last-observation freshness label; document each system's actual refresh interval.
10. README includes 1-page setup per profile, estimated cost categories (not fabricated live prices), run/stop/cleanup commands, troubleshooting for Apple Silicon and no-credentials path.

### Delivery sequence / pull requests

- **PR 1** `feat/common-weather-contract`: shared typed events/config and fixtures, SQL model contract tests, preserve v3.
- **PR 2** `feat/clickhouse-local-stream`: Redpanda/CH Docker Compose, producer, consumer, raw/MV SQL, e2e.
- **PR 3** `feat/gcp-native-local`: Pub/Sub client/emulator + DirectRunner/TestStream + BigQuery SQL, no cloud costs.
- **PR 4** `feat/clickhouse-cloud-profile`: Confluent Basic + ClickPipes IaC/docs and manual smoke.
- **PR 5** `feat/gcp-native-cloud`: GCP Pub/Sub/BigQuery Subscription/Cloud Run/Scheduler IaC/docs and manual smoke. Optional Dataflow full deployment follows once the minimal route passes.
- **PR 6** `feat/multi-profile-dashboards`: code-driven dashboards and unified performance comparison.

Each PR must include tests, docs, `git diff --check`, a brief execution report (actually executed / skipped with reason), and explicit costs/external prerequisites. Do not open PRs or write into GitHub until the correct repository, permissions and remote are confirmed. **No auto-archive, auto-fork, force-push or destructive cleanup of user data.**

## 7. Useful primary references

- [Redpanda local Compose](https://docs.redpanda.com/labs/docker-compose/single-broker/)
- [Confluent Cloud Basic setup](https://docs.confluent.io/cloud/current/clusters/create-cluster.html)
- [ClickHouse Cloud ClickPipes Kafka docs](https://clickhouse.com/docs/integrations/data-ingestion/clickpipes/kafka/reference)
- [ClickPipes delivery semantics](https://clickhouse.com/docs/integrations/data-ingestion/clickpipes/kafka/best-practices)
- [GCP BigQuery subscriptions](https://docs.cloud.google.com/pubsub/docs/bigquery)
- [GCP Dataflow local and test guide](https://docs.cloud.google.com/dataflow/docs/guides/develop-and-test-pipelines)
- [GCP Pub/Sub Emulator limitations](https://docs.cloud.google.com/pubsub/docs/emulator)
- [Cloud Run Jobs scheduling](https://docs.cloud.google.com/run/docs/execute/jobs-on-schedule)
- [GCP BigQuery materialized views](https://docs.cloud.google.com/bigquery/docs/materialized-views-use)
- [MiniLake](https://dmux.github.io/minilake/)


## 8. Claude Code handoff and repository permissions

Use the companion `CLAUDE_CODE_WEATHER_DFE_PROMPT.md` as the kickoff prompt and this document as the acceptance contract. The developer's machine previously reported the working path `/Users/user/gi/@dataengy/weather_dfe`; **ChatGPT sandbox paths are not available there** until the user downloads a file. An explicit source archive is `/mnt/data/weather_dfe_v3.zip` in ChatGPT, with archive root `weather_dfe/`. Download it locally first, if the checkout is empty.

Previously the GitHub connector could read `beloz978/weather_dfe` as public but lacked push permission, whereas a subsequent connector check returned HTTP 404 for both candidate repositories. Do not infer deletion, privacy, ownership, or fork availability from that inconsistent access signal. The local `gh` client also reported invalid identities and an x509 error. Re-check after authentication and ask the user which repository is canonical before any destructive or remote action.

For reproducibility, the agent should record the actual installed Python, PySpark, Beam and Docker image versions in its completion report and pin tested compatible versions; it should not treat unverified version guesses as compatible.

## 9. Handoff package layout

This single ZIP contains extracted `weather_dfe/` v3 source, `baseline/weather_dfe_v3.zip` and the original self-contained generator for provenance, updated docs including the local-first reuse policy and draft local debug plans, `scripts/discover_local_runtime.py` (read-only preflight), and draft SQL/Beam examples under `drafts/`. Draft assets must not be mistaken for completed integrations.
