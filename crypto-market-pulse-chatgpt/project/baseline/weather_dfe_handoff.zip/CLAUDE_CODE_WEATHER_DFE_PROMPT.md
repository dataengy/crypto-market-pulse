# Claude Code handoff — Weather DFE: add ClickHouse and native GCP streaming profiles

You are implementing the **Weather DFE multi-profile streaming MVP**. The complete, authoritative specification is `WEATHER_DFE_MULTI_PROFILE_SPEC.md` (place it in the repository's `docs/` directory or provide its local absolute path).

## Mandatory local runtime discovery before installing anything

Strict priority: **(1)** existing host applications/binaries (search `PATH`, `~/.apps/`, `~/.app/`), **(2)** already-existing Docker/Colima containers and images, **(3)** newly installed or launched dependencies **only if needed**. This applies to **ClickHouse, Redpanda/Kafka, Spark, PostgreSQL, MiniLake, Airbyte, and every other dependency/tool**.

**First run:** `python3 scripts/discover_local_runtime.py --markdown` (read-only). Inspect Docker contexts, `docker ps -a`, `docker compose ls --all`, `colima list`, `~/.apps/` and `~/.app/`. Record selected host/container endpoint, compatibility, owner and cleanup boundaries for each component. Read `docs/local/LOCAL_RUNTIME_REUSE_POLICY.md`, `docs/local/CLICKHOUSE_LOCAL_DEBUG.md` and `docs/local/GCP_LOCAL_DEBUG.md` before any deployment.

Reuse must be safe: never reconfigure, stop, delete or `down -v` externally managed containers/volumes, or overwrite existing databases/topics. If suitable compatible services are already available, don't install another copy. Where needed, use a separate logical DB/topic and isolated consumer group, and ask permission for mutating operations. Make `up`/`down` commands idempotent; `down` must not touch reused resources. New Compose images and services are **last resort**.

## Workspace / source-of-truth checks (do first)

1. Inspect local worktree `/Users/user/gi/@dataengy/weather_dfe`: `pwd`, `git status --short --branch`, `git remote -v`, `git log -3 --oneline`, current tracked files. Do NOT assume the worktree is empty or safe to overwrite.
2. Check `gh auth status -h github.com` and independently verify read access to the intended canonical repository. The user has referenced **both** `beloz978/weather_dfe` and `dataengy/weather_dfe`, and credentials/TLS were previously broken. Treat missing access as a blocker **only for remote operations**, not for local implementation.
3. If the worktree has no Weather DFE source, use this handoff ZIP’s extracted `weather_dfe/` code (or `baseline/weather_dfe_v3.zip`) and ask the operator for its **local macOS path** if the archive is not already available. Never assume `/mnt/data/...` is available on the Mac. Inspect archive contents before copying. The archive root is `weather_dfe/`.
4. The included Weather DFE v3 baseline contains 32 files, including `sql/models/`, `sql/pipelines/`, local PySpark, MiniLake, a `justfile`, and workflows. Preserve the baseline and report any problems you discover in it.
5. **No automatic archive, fork, rename, force-push, remote update or deletion**. If repository ownership/fork destination is ambiguous, perform local work and report two concrete options for the user to choose.
6. Create a dedicated `feat/weather-multi-profile-streaming` branch only after examining the baseline. Use Conventional Commits. Don't push or open a PR until the user confirms destination and working authentication, as requested in the prior exchange.

## Architectural profiles

Preserve existing `databricks` profile. Add:

**Profile `clickhouse`:**
- Local: Open-Meteo/synthetic producer → Redpanda Kafka API (reuse existing local container where safe) → restartable lightweight Kafka consumer → ClickHouse OSS (`MergeTree`) → SQL marts (`weather_latest`, `weather_1m`) → dashboard.
- Hosted: shared producer → **Confluent Cloud Basic (GCP)** → **ClickPipes Kafka in ClickHouse Cloud** → SQL marts → dashboard. This is the initial managed Kafka choice; don't provision AWS MSK, GKE or self-managed Kafka for v1.
- The local Kafka consumer is a debug substitute, **not** a ClickPipes emulator. Commit Kafka offsets only after confirmed ClickHouse write, test crash/retry/duplicates. Define delivery semantics and explicitly prove deduplicated query results. Keep cloud smoke manual and cost-controlled.

**Profile `gcp`:**
- Lowest-complexity managed MVP: **Cloud Scheduler → Cloud Run Job → Pub/Sub → native BigQuery Subscription → BigQuery raw → SQL marts**. No Dataflow needed in this primary path.
- Advanced path: **Pub/Sub → Apache Beam/DataflowRunner → BigQuery** with event-time, watermark, lateness and DLQ. Scaffold it and implement `TestStream` and `DirectRunner` tests locally; don't require paid Dataflow deployment in the first PR.
- Local: Beam `DirectRunner` + `TestStream` for deterministic stream tests, Pub/Sub Emulator for producer/consumer integration. **The emulator never sends BigQuery subscription messages to BigQuery**, so a separate opt-in real-GCP smoke test must cover the managed subscription.

**Cross-cutting**:
- One normalized, versioned event schema with immutable `event_id`, distinct provider `observed_at` and polling `collected_at`, clear dedup semantics, invalid/out-of-order/late/repeated fixtures, separate real vs synthetic modes.
- Shared *logical* mart definitions and dialect-specific `.sql` files. Keep `settings.yml`, profile YAML, typed `settings.py`, small pure `utils.py`, HTTP collector, publishers and engine logic separate. Do not silently rewrite all transformations in Python.
- Explicit `WEATHER_PROFILE`, per-profile `just` commands; local defaults only, cloud credentials fail fast; secrets only via environment / secrets manager, never git.
- Add GitHub Actions PR CI (ruff/pytest/config/SQL generator drift), Docker integration CI (Redpanda+CH), Beam TestStream and Pub/Sub Emulator tests; optional, manually triggered cloud smoke with spending guard and teardown. Keep existing local PySpark/MiniLake lanes.
- Dashboard as code for the three engines: at least temperature/humidity/wind/history, selected city, freshness indicator. If a dashboard cannot be fully provisioned as code, document exactly which UI action remains and keep versioned SQL/config.

## Execution order and scope control

Work in short, verifiable milestones. Start with shared event contract/config/fixtures + regression tests. Next implement the fully local ClickHouse path; then local Beam/emulator; only then write cloud Terraform and scripts. Do not claim production-readiness from local success. The full phase/PR and acceptance plan is in `WEATHER_DFE_MULTI_PROFILE_SPEC.md`.

At the end of each milestone, return a short **evidence-based** report:
- changed files and git diff summary;
- exact commands run with exit status;
- tests passed, failed, skipped (why);
- expected/actual duplicate and lateness behavior;
- remaining operational costs, credentials, cloud requirements;
- one next step.

Never invent a green CI, successful Terraform apply, working cloud connection, GitHub permissions, or uploaded PR. Do not turn off SSL verification as a workaround for `gh` TLS errors; diagnose trust/keychain/CA configuration separately.

## Expanded acceptance for local-first reuse

For each requested profile, first present an inventory of host tools and Docker/Colima resources. Explain your chosen provider and non-destructive reuse checks. The initial PR must include discovery helper tests. CI remains hermetic and uses fresh ephemeral services independent of the developer's existing machines. The ClickHouse/GCP local draft documents are the implementation starting points; replace proposed targets with actual verified commands and checks as they are implemented.
